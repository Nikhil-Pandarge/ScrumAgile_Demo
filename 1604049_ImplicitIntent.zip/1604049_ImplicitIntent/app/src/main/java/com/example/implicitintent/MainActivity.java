package com.example.implicitintent;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.util.logging.Handler;

public class MainActivity extends AppCompatActivity {

    EditText ed1;
    public void callintent(View view) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            String num = ed1.getText().toString();
            Intent i = new Intent(Intent.ACTION_CALL,Uri.parse("tel:" + num));
            startActivity(i);
        }
        else
        {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CALL_PHONE},1);
        }

    }
    public void dialintent(View view)
    {
        String num = ed1.getText().toString();
        Intent i = new Intent(Intent.ACTION_DIAL,Uri.parse("tel:" + num));
        startActivity(i);
    }
    public void conintent(View view)
    {
        String num = ed1.getText().toString();
        Intent i = new Intent(Intent.ACTION_VIEW,Uri.parse("content://contacts/people"));
        startActivity(i);
    }
    public void brintent(View view)
    {
        Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/"));
        startActivity(i);
    }
    public void call_logintent(View view)
    {
        Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("content://call_log/calls/"));
        startActivity(i);
    }
    public void galintent(View view)
    {
        Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("content://media/external/images/media"));
        startActivity(i);

    }
    public void camintent(View view)
    {
        Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivity(i);
    }
    public void vidintent(View view)
    {
        Intent i=new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        startActivity(i);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.editText);
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA,Manifest.permission.CALL_PHONE},1);
    }
}
