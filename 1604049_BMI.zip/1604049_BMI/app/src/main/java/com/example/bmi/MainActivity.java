package com.example.bmi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText ed1,ed2;
    TextView ans1;
    double bmi,weight, height;
    public boolean fieldcheck()
    {
        if(ed1.getText().toString().isEmpty() && ed2.getText().toString().isEmpty())
        {
            Toast.makeText(this, "Please enter both of the fields", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(ed1.getText().toString().isEmpty() || ed2.getText().toString().isEmpty())
        {
            if(ed1.getText().toString().isEmpty())
                Toast.makeText(this, "Enter weight", Toast.LENGTH_SHORT).show();

            else
                Toast.makeText(this, "Enter height", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(!ed1.getText().toString().isEmpty() && !ed2.getText().toString().isEmpty())
        {
            return true;
        }
        else
            return false;
    }
    public boolean isNumeric() {
        try {
            weight = Double.parseDouble(ed1.getText().toString());
            height = Double.parseDouble(ed2.getText().toString());
        }
        catch(NumberFormatException nfe)
        {
            Toast.makeText(this, "Enter Numeric Values", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    public void bmical(View view)
    {
        if(fieldcheck()) {
            if (isNumeric()) {
                //System.out.println("Weight:" + weight + " Height" + height);
                double hm = height / 100;
                bmi = (weight / (hm * hm));
                //System.out.println(bmi);
                String state = null;
                if (bmi >= 18.5 && bmi <= 24.9)
                    state = "Normal";
                else if (bmi >= 25)
                    state = "Overweight";
                else
                    state = "Underweight";
                String answ = Double.toString(bmi) + "-" + state;
                ans1.setText(answ);
                // Toast.makeText(this, answ, Toast.LENGTH_SHORT).show();
            }
        }

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        ans1=findViewById(R.id.ans);
        ed1=findViewById(R.id.weight);
        ed2=findViewById(R.id.height);
    }
}
